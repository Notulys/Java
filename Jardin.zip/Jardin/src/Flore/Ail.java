package Flore;

public class Ail extends Vegetal {

	public Ail(Vegetal dessin) {
		super();
		super.dessin[3] = "a";
		super.dessin[4] = "A";
	}
}
